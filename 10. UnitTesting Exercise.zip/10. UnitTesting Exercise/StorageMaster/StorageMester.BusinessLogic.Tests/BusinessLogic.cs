﻿namespace StorageMester.BusinessLogic.Tests
{
    using NUnit.Framework;
    using System;
    using StorageMaster.Core;
    using System.Reflection;
    using System.Linq;
    using System.Collections.Generic;

    [TestFixture]
    public class BusinessLogic
    {
        private Type storageType;
        private StorageMaster storageMaster;

        [SetUp]
        public void Initialize()
        {
            this.storageType = typeof(StorageMaster);
            this.storageMaster = new StorageMaster();
        }

        [Test]
        public void TestFields()
        {
            FieldInfo[] fields = storageType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            bool containsRegistry = fields.Any(x => x.Name == "storageRegistry");
            bool containsPool = fields.Any(x => x.Name == "productsPool");
            bool containsCurrentVehicle = fields.Any(x => x.Name == "currentVehicle");

            Assert.IsTrue(containsRegistry);
            Assert.IsTrue(containsPool);
            Assert.IsTrue(containsCurrentVehicle);
        }

        [Test]
        public void AddProductMethod()
        {
            string returnString = storageMaster.AddProduct("Ram", 22);
            Assert.AreEqual(returnString, $"Added Ram to pool");
        }

        [Test]
        public void TestRegisterStorage()
        {
            string returnString = storageMaster.RegisterStorage("Warehouse", "Test");
            Assert.AreEqual(returnString, "Registered Test");
        }

        [Test]
        public void TestSelectVehicle()
        {
            storageMaster.RegisterStorage("Warehouse", "Test");
            string returned = storageMaster.SelectVehicle("Test", 1);
            Assert.AreEqual(returned, "Selected Semi");
        }

        [Test]
        public void TestLoadVehicle()
        {
            List<string> temp = new List<string>()
            {
                "notexisting", "test"
            };
            Assert.Throws<InvalidOperationException>(() => storageMaster.LoadVehicle(temp));
        }
    }
}
