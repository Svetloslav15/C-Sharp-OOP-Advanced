﻿namespace StorageMester.Tests.Structure
{
    using NUnit.Framework;
    using StorageMaster.Entities.Products;
    using StorageMaster.Entities.Vehicles;
    using System;
    using System.Reflection;

    [TestFixture]
    public class VehiclesTests
    {
        [Test]
        public void TestVehicle()
        {
            Type type = typeof(Vehicle);
            Assert.AreEqual(type.IsAbstract, true);

            ConstructorInfo ctor = type.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic)[0];
            Assert.IsNotNull(ctor);
            Assert.AreEqual(ctor.IsFamily, true);

            MethodInfo[] methods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance);
            Assert.AreEqual(methods.Length, 10);
        }

        [Test]
        public void TestVan()
        {
            Van van = new Van();
            Assert.AreEqual(van.Capacity, 2);
            Assert.AreEqual(van.IsEmpty, true);
            Assert.AreEqual(van.IsFull, false);
            Assert.AreEqual(van.Trunk.Count, 0);

            van.LoadProduct(new Ram(23));
            Assert.AreEqual(van.Trunk.Count, 1);
            van.Unload();
            Assert.AreEqual(van.Trunk.Count, 0);
            Assert.Throws<InvalidOperationException>(() => van.Unload());
        }

        [Test]
        public void TestSemi()
        {
            Semi semi = new Semi();
            Assert.AreEqual(semi.Capacity, 10);
            Assert.AreEqual(semi.IsEmpty, true);
            Assert.AreEqual(semi.IsFull, false);
            Assert.AreEqual(semi.Trunk.Count, 0);

            semi.LoadProduct(new Ram(23));
            Assert.AreEqual(semi.Trunk.Count, 1);
            semi.Unload();
            Assert.AreEqual(semi.Trunk.Count, 0);
            Assert.Throws<InvalidOperationException>(() => semi.Unload());
        }

        [Test]
        public void TestTruck()
        {
            Truck truck = new Truck();
            Assert.AreEqual(truck.Capacity, 5);
            Assert.AreEqual(truck.IsEmpty, true);
            Assert.AreEqual(truck.IsFull, false);
            Assert.AreEqual(truck.Trunk.Count, 0);

            truck.LoadProduct(new Ram(23));
            Assert.AreEqual(truck.Trunk.Count, 1);
            truck.Unload();
            Assert.AreEqual(truck.Trunk.Count, 0);
            Assert.Throws<InvalidOperationException>(() => truck.Unload());
        }
    }
}
