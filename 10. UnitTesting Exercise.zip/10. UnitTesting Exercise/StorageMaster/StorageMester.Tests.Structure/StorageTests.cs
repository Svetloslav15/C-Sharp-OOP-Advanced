﻿namespace StorageMester.Tests.Structure
{
    using NUnit.Framework;
    using System;
    using StorageMaster.Entities.Storage;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Linq;

    [TestFixture]
    public class StorageTests
    {
        [Test]
        public void TestBaseField()
        {
            Type type = typeof(Storage);
            Assert.AreEqual(type.IsAbstract, true);
            FieldInfo garage = type.GetField("garage", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.AreEqual(garage.IsInitOnly, true);

            PropertyInfo[] props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            PropertyInfo name = type.GetProperty("Name", (BindingFlags)62);
            Assert.AreEqual(name.CanRead, true);
            Assert.AreEqual(name.CanWrite, false);

            string getGarage = type.GetMethod("get_Garage").ReturnType.Name;
            Assert.AreEqual(getGarage.StartsWith("IReadOnlyCollection"), true);
            string getProducts = type.GetMethod("get_Products").ReturnType.Name;
            Assert.AreEqual(getProducts.StartsWith("IReadOnlyCollection"), true);

            MethodInfo capacity = type.GetMethod("get_Capacity");
            MethodInfo isFull = type.GetMethod("get_IsFull");
            MethodInfo garageSlots = type.GetMethod("get_GarageSlots");
            MethodInfo sendVehicleTo = type.GetMethod("SendVehicleTo");
            MethodInfo unloadVehicle = type.GetMethod("UnloadVehicle");
            
            Assert.AreNotEqual(garageSlots, null);
            Assert.AreNotEqual(isFull, null);
            Assert.AreNotEqual(capacity, null);
            Assert.AreNotEqual(sendVehicleTo, null);
            Assert.AreNotEqual(unloadVehicle, null);
        }

        [Test]
        public void TestWareHouse()
        {
            Type warehouseType = typeof(Warehouse);

            var wareHouseVehicles = warehouseType.GetField("DefaultVehicles",
                BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(null);
            Assert.AreNotEqual(wareHouseVehicles, null);

            Warehouse warehouse = new Warehouse("Test");
            Assert.AreEqual(warehouse.Capacity, 10);
            Assert.AreEqual(warehouse.GarageSlots, 10);
        }

        [Test]
        public void TestAutomatedWarehouse()
        {
            Type warehouseType = typeof(AutomatedWarehouse);

            var wareHouseVehicles = warehouseType.GetField("DefaultVehicles",
                BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(null);
            Assert.AreNotEqual(wareHouseVehicles, null);

            AutomatedWarehouse warehouse = new AutomatedWarehouse("Test");
            Assert.AreEqual(warehouse.Capacity, 1);
            Assert.AreEqual(warehouse.GarageSlots, 2);
        }

        [Test]
        public void TestDistibutionCennter()
        {
            Type warehouseType = typeof(DistributionCenter);

            var distributionCenter = warehouseType.GetField("DefaultVehicles",
                BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(null);
            Assert.AreNotEqual(distributionCenter, null);

            DistributionCenter instance = new DistributionCenter("Test");
            Assert.AreEqual(instance.Capacity, 2);
            Assert.AreEqual(instance.GarageSlots, 5);
        }
    }
}
