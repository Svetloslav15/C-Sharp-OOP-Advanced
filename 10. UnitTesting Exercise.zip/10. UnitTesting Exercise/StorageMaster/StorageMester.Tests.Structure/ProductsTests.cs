﻿namespace StorageMester.Tests.Structure
{
    using NUnit.Framework;
    using StorageMaster.Entities.Products;
    using System;
    using System.Linq;
    using System.Reflection;

    [TestFixture]
    public class ProductsTests
    {
        private Type productType;

        [SetUp]
        public void StartUp()
        {
            productType = typeof(Product);
        }

        [Test]
        public void TestBaseProductClass() 
        {
            Type type = typeof(Product);
            Assert.AreEqual(type.IsAbstract, true);

            FieldInfo[] fields = type.GetFields(BindingFlags.Static | BindingFlags.Public);
            Assert.AreEqual(fields.Length, 0);

            ConstructorInfo[] ctors = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.AreEqual(ctors.Length, 1);

            PropertyInfo[] props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            Assert.AreEqual(props.Length, 2);
        }

        [Test]
        public void GpuTest()
        {
            Type type = typeof(Gpu);
            ConstructorInfo ctor = type.GetConstructor(new Type[] { typeof(double) });
            Gpu gpu = (Gpu)ctor.Invoke(new object[] { 4.2});
            Assert.AreEqual(gpu.Price, 4.2);
            Assert.AreEqual(gpu.Weight, 0.7);
            Assert.AreEqual(type.IsSubclassOf(this.productType), true);
        }

        [Test]
        public void HardDriveTest()
        {
            Type type = typeof(HardDrive);
            ConstructorInfo ctor = type.GetConstructor(new Type[] { typeof(double) });
            HardDrive hardDrive = (HardDrive)ctor.Invoke(new object[] { 4.2 });
            Assert.AreEqual(hardDrive.Price, 4.2);
            Assert.AreEqual(hardDrive.Weight, 1);
            Assert.AreEqual(type.IsSubclassOf(this.productType), true);

        }

        [Test]
        public void RamTest()
        {
            Type type = typeof(Ram);
            ConstructorInfo ctor = type.GetConstructor(new Type[] { typeof(double) });
            Ram ram = (Ram)ctor.Invoke(new object[] { 4.2 });
            Assert.AreEqual(ram.Price, 4.2);
            Assert.AreEqual(ram.Weight, 0.1);
            Assert.AreEqual(type.IsSubclassOf(this.productType), true);

        }

        [Test]
        public void SolidStateDriveTest()
        {
            Type type = typeof(SolidStateDrive);
            ConstructorInfo ctor = type.GetConstructor(new Type[] { typeof(double) });
            SolidStateDrive solidStateDrive = (SolidStateDrive)ctor.Invoke(new object[] { 4.2 });
            Assert.AreEqual(solidStateDrive.Price, 4.2);
            Assert.AreEqual(solidStateDrive.Weight, 0.2);
            Assert.AreEqual(type.IsSubclassOf(this.productType), true);

        }
    }
}
